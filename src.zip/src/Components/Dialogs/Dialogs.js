import React from "react";
import "./dialogs.css";

export const Dialogs = () => {
    return (
        <div>
            dialog
        </div>
    )
}
