import React from "react";
import "./feed.css";
import Photo from "../../image/photo.svg";
import Friend from "../../image/tagFriend.svg";
import Feelings from "../../image/feelings.svg";
import {HeaderPosts} from "./HeaderPosts";
import {CreatePost} from "./CreatePost";
// import {userName} from "../Components/Header/Header";

export const Feed = () => {
    return (
        <div className="main-feed">
            <HeaderPosts/>
            <CreatePost likes='43' />
            <CreatePost likes='23' />
            <CreatePost likes='3'/>
        </div>
    )
}
