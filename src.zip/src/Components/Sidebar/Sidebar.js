import React from "react";
import "./sidebar.css";
import User from "../../image/user.svg";
import Profile from "../../image/profile.svg";
import Messages from "../../image/messages.svg";
import News from "../../image/news.svg";
import Music from "../../image/music.svg";
import Settings from "../../image/settings.svg";
import {NavLink} from "react-router-dom";

export const Sidebar = () => {
    return (
        <div className="menu-sidebar">
            <div className="user">
                <img src={User} alt="Avatar" className="sidebar-avatar"/>
                <span className="user-name">
              Kachalko Stanislav
            </span>
            </div>
            <nav className="nav-group">
                <NavLink to="/profile" className="group-link">
                    <img src={Profile} alt="user"/>
                    <span className="group-text">
                        Profile
                    </span>
                </NavLink>
                <NavLink to="/messages" className="group-link">
                    <img src={Messages} alt="Messages"/>
                    <span className="group-text">
                        Messages
                    </span>
                </NavLink>
                <NavLink to="/news" className="group-link">
                    <img src={News} alt="Messages"/>
                    <span className="group-text">
                        News
                    </span>
                </NavLink>
                <NavLink to="/music" className="group-link">
                    <img src={Music} alt="Messages"/>
                    <span className="group-text">
                        Music
                    </span>
                </NavLink>

                <NavLink to="/settings" className="group-link">
                    <img src={Settings} alt="Messages"/>
                    <span className="group-text">
                        Settings
                    </span>
                </NavLink>
            </nav>
        </div>
    );

}
